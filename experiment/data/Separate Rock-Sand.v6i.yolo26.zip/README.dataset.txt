# Separate Rock&Sand > 2026-06-04 1:45am
https://universe.roboflow.com/ai-training-y3t1/separate-rock-sand

Provided by a Roboflow user
License: CC BY 4.0

