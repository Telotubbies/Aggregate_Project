# Piled Materials > 2024-11-01 2:38pm
https://universe.roboflow.com/dataset-piled-materials/piled-materials

Provided by a Roboflow user
License: CC BY 4.0

